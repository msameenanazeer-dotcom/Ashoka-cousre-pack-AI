const courses = [
  {
    id:'adsa', code:'R232PC31', name:'ADSA', full:'Advanced Data Structures & Algorithm Analysis', faculty:'Ranganayakulamma', pack:'course-packs/ADSA.pdf',
    units:[
      ['Unit I','AVL Trees, B-Trees, Heap Trees (Priority Queues), B+ Trees, Red-Black Trees.'],
      ['Unit II','Divide and Conquer, Quick Sort, Merge Sort, Strassen’s Matrix Multiplication, Convex Hull.'],
      ['Unit III','Greedy Method, Job Sequencing, Knapsack, Minimum Cost Spanning Trees, Single Source Shortest Paths, Dynamic Programming, Bellman-Ford, Optimal BST, Travelling Salesperson.'],
      ['Unit IV','Backtracking, 8-Queens, Sum of Subsets, Graph Coloring, Branch and Bound, 0/1 Knapsack, Travelling Salesperson.'],
      ['Unit V','NP-Hard and NP-Complete Problems, Cook’s theorem, Clique Decision Problem, Chromatic Number Decision Problem, TSP Decision Problem, scheduling problems.']
    ]
  },
  {
    id:'oopj', code:'R232PC32', name:'OOPJ', full:'Object-Oriented Programming Through Java', faculty:'Mr Rama Krishna Reddy', pack:'course-packs/OOPJ.pdf',
    units:[
      ['Unit I','Object-oriented programming basics, Java program structure, tokens, statements, input, comments, data types, variables, operators and control statements.'],
      ['Unit II','Classes and Objects, constructors, overloaded methods, access control, recursive methods, this, final and static.'],
      ['Unit III','Arrays, inheritance, multilevel inheritance, super, method overriding, dynamic method dispatch, abstract classes and interfaces.'],
      ['Unit IV','Packages and Java library, exception hierarchy, try/catch/finally, checked and unchecked exceptions, Java I/O and files.'],
      ['Unit V','String handling, multithreaded programming, thread lifecycle, priorities, synchronization, deadlock and inter-thread communication.']
    ]
  },
  {
    id:'dmgt', code:'R23BS31', name:'DMGT', full:'Discrete Mathematics & Graph Theory', faculty:'Venkat NAIDU', pack:'course-packs/DMGT.pdf',
    units:[
      ['Unit I','Mathematical Logic: statements, connectives, well-formed formulas, tautology, equivalence, implication, normal forms and inference.'],
      ['Unit II','Set Theory, inclusion-exclusion, pigeonhole principle, functions, recursive functions, lattices, semigroups, monoids, groups, homomorphism and isomorphism.'],
      ['Unit III','Elementary Combinatorics: combinations, permutations, repetitions, constrained repetitions, binomial and multinomial theorems.'],
      ['Unit IV','Recurrence Relations: generating functions, coefficients, substitution method, characteristic roots and inhomogeneous recurrence relations.'],
      ['Unit V','Graphs: basic concepts, isomorphism, subgraphs, trees, spanning trees, directed trees, binary trees, planar graphs, Euler circuits and Hamiltonian graphs.']
    ]
  },
  {
    id:'uhv', code:'R23HM31', name:'UHV', full:'Universal Human Values – Understanding Harmony and Ethical Human Conduct', faculty:'C NITYA', pack:'course-packs/UHV.pdf',
    units:[
      ['Unit I','Introduction to Value Education: self-exploration, natural acceptance, happiness and prosperity, and understanding the human being.'],
      ['Unit II','Harmony in the Human Being: needs of self and body, self-regulation, and harmony between self and body.'],
      ['Unit III','Harmony in the Family and Society: trust, respect, relationships, justice and mutually fulfilling interaction.'],
      ['Unit IV','Harmony in the Nature (Existence): four orders of nature, mutual fulfilment and co-existence.'],
      ['Unit V','Implications of Holistic Understanding: natural acceptance, ethical human conduct, professional ethics, humanistic education and value-based living.']
    ]
  },
  {
    id:'ai', code:'R233PC31', name:'AI', full:'Artificial Intelligence', faculty:'M Sameena Nazeer', pack:'course-packs/AI.pdf',
    units:[
      ['Unit I','AI problems, foundations and history, intelligent agents, environments, rationality, agent structure, problem-solving agents and problem formulation.'],
      ['Unit II','Search: breadth-first search, depth-first search, heuristic search, hill climbing, A*, AO*, problem reduction, game playing and minimax.'],
      ['Unit III','Knowledge representation, predicate logic, semantic networks, frames and inheritance, constraint propagation, rules, forward chaining, backward chaining, resolution, uncertainty, Bayes and Dempster-Shafer theory.'],
      ['Unit IV','Functional Learning: introduction to machine learning, supervised and unsupervised learning, decision trees, explanation-based learning, statistical learning, reinforcement learning and AI applications.'],
      ['Unit V','Expert systems, knowledge acquisition, MYCIN, DART, XCON, AI hardware (GPU/TPU/NPU), ethics, generative AI, LLMs, prompt engineering and RAG.']
    ]
  }
];

const grid = document.getElementById('courseGrid');

function renderCourses(){
  grid.innerHTML = courses.map(c => `
    <article class="course-card">
      <span class="code">${c.code}</span>
      <div class="course-title">${c.name} — ${c.full}</div>
      <div class="faculty">👨‍🏫 Faculty: <strong>${c.faculty}</strong></div>
      <div class="details">
        <a class="action primary-link" href="${c.pack}" target="_blank" rel="noopener">📘 Course Pack</a>
        <button class="action" data-unit="${c.id}">View Units</button>
      </div>
      <div id="units-${c.id}" class="units">
        ${c.units.map((u, i) => `
          <div class="unit">
            <h4>${u[0]} </h4>
            <p>${u[1]}</p>
            <div class="video-list">
              <a href="https://www.youtube.com/results?search_query=${encodeURIComponent(c.name+' '+u[0])}" target="_blank" rel="noopener">▶ YouTube search</a>
            </div>
          </div>`).join('')}
      </div>
    </article>
  `).join('');

  document.querySelectorAll('[data-unit]').forEach(btn => {
    btn.addEventListener('click', () => document.getElementById('units-'+btn.dataset.unit).classList.toggle('open'));
  });
}

function showSection(id){
  document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.section===id));
  window.scrollTo({top:0,behavior:'smooth'});
}

document.querySelectorAll('.nav-btn').forEach(btn=>btn.addEventListener('click',()=>showSection(btn.dataset.section)));
document.querySelectorAll('[data-jump]').forEach(btn=>btn.addEventListener('click',()=>showSection(btn.dataset.jump)));

renderCourses();

let deferredPrompt;
const installBtn=document.getElementById('installBtn');
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;installBtn.hidden=false;});
installBtn.addEventListener('click',async()=>{if(!deferredPrompt){return;}deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;installBtn.hidden=true;});
window.addEventListener('appinstalled',()=>{installBtn.hidden=true;});

if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(console.error));}
