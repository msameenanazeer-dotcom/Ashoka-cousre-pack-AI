# Online Class Portal – 5 Course Packs

GitHub-ready static website for:
- ADSA — Ranganayakulamma
- OOPJ — Mr Rama Krishna Reddy
- DMGT — Venkat NAIDU
- UHV — C NITYA
- AI — M Sameena Nazeer

## Upload course packs
Place the actual files in `course-packs/` with these exact names:
- `ADSA.pdf`
- `OOPJ.pdf`
- `DMGT.pdf`
- `UHV.pdf`
- `AI.pdf`

Then commit and push to GitHub. The Course Pack buttons in the site will open those files.

## Vercel
Import the GitHub repository into Vercel. No build command is required for this static site.
